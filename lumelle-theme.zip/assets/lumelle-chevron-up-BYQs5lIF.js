import{a as e}from"./lumelle-bundle.js";
/**
 * @license lucide-react v0.548.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const a=e("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]),o=e("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{o as C,a};
