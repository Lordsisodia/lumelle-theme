# Terms of Service

Welcome to SISO. By using the platform, you agree to these terms.

## Acceptable Use
- Don’t misuse the service or attempt to disrupt it.
- Respect other users and intellectual property.

## Accounts
- Keep your credentials secure.
- You’re responsible for activity under your account.

## Liability
- The service is provided “as is”.
- We limit liability to the maximum extent permitted by law.

## Changes
- We may update these terms; we’ll notify you when changes are material.

## Contact
- legal@siso.example
